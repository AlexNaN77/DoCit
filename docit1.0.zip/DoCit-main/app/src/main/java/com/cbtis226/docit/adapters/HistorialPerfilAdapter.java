package com.cbtis226.docit.adapters;

import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.cbtis226.docit.R;
import com.cbtis226.docit.model.Cita;
import com.squareup.picasso.Picasso;
import java.util.List;

public class HistorialPerfilAdapter extends RecyclerView.Adapter<HistorialPerfilAdapter.VH> {

    List<Cita> data;
    public HistorialPerfilAdapter(List<Cita> d){ data = d; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int v) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_cita_min, p, false));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        Cita c = data.get(pos);
        if(c.doctor != null){
            h.tDoc.setText(c.doctor.nombreDr());
            h.tEmail.setText(c.doctor.correo != null ? c.doctor.correo : "email@fakedomain.net");
            if(c.doctor.fotoPerfil != null && !c.doctor.fotoPerfil.isEmpty()){
                Picasso.get().load(c.doctor.fotoPerfil)
                        .placeholder(R.drawable.ic_medico).into(h.img);
            }
        }
    }

    @Override public int getItemCount(){ return data == null ? 0 : data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tDoc, tEmail;
        ImageView img;
        VH(View v){
            super(v);
            tDoc = v.findViewById(R.id.txtDoctor);
            tEmail = v.findViewById(R.id.txtEmailDoc);
            img = v.findViewById(R.id.imgDoc);
        }
    }
}