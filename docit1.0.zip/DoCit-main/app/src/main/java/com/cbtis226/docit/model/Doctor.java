package com.cbtis226.docit.model;

import java.util.List;

public class Doctor {
    public String idDoctor;
    public String nombre;
    public String apellidoPaterno;
    public String apellidoMaterno;
    public String correo;
    public String telefono;
    public String cedulaProfesional;
    public String fotoPerfil;
    public String descripcion;
    public String whatsapp;
    public Double promedioCalificacion;
    public String estadoCuenta;
    public String fechaRegistro;

    // campos nuevos que vienen de la base de datos importada
    public String direccion;
    public String mapsUrl;
    public String horarioTexto;

    public Especialidad especialidad;
    public Consultorio consultorio;
    public List<Servicio> servicios;
    public List<HorarioDisponible> horarios;
    public List<Imagen> imagenes;
    public List<Resena> resenas;

    public String nombreDr(){
        String n = nombre == null ? "" : nombre.trim();
        String ap = apellidoPaterno == null ? "" : apellidoPaterno.trim();
        String completo = (n + " " + ap).trim();
        if(completo.isEmpty()) return "Doctor";
        // si ya empieza con "Dr" no le ponemos otro
        String lower = completo.toLowerCase();
        if(lower.startsWith("dr.") || lower.startsWith("dr ") ||
                lower.startsWith("dra.") || lower.startsWith("dra ")){
            return completo;
        }
        return "Dr. " + completo;
    }
}
