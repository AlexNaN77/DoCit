package com.cbtis226.docit.adapters;

import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.cbtis226.docit.R;
import com.cbtis226.docit.model.Especialidad;
import java.util.List;

public class EspecialidadAdapter extends RecyclerView.Adapter<EspecialidadAdapter.VH> {

    public interface OnClick { void click(Especialidad e); }

    List<Especialidad> data;
    OnClick cb;

    public EspecialidadAdapter(List<Especialidad> d, OnClick c){ data=d; cb=c; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int viewType) {
        View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_especialidad, p, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Especialidad e = data.get(pos);
        h.tv.setText(e.nombre);

        // icono custom segun el nombre de la especialidad
        h.icono.setImageResource(iconoPara(e.nombre));

        // color pastel rotativo segun posicion, pa que no se vea aburrido
        int[] colores = {
                R.color.pastelAzul, R.color.pastelVerde, R.color.pastelAmarillo,
                R.color.pastelRosa, R.color.pastelMorado
        };
        h.card.setCardBackgroundColor(
                h.itemView.getContext().getResources().getColor(colores[pos % colores.length]));

        h.itemView.setOnClickListener(v -> cb.click(e));
    }

    // mapea el nombre de la especialidad a su PNG. si no machea, usa el generico.
    private int iconoPara(String nombre){
        if(nombre == null) return R.drawable.ic_medico;
        String n = nombre.toLowerCase()
                .replace("á","a").replace("é","e").replace("í","i")
                .replace("ó","o").replace("ú","u");
        if(n.contains("cardio")) return R.drawable.esp_cardiologia;
        if(n.contains("nutri")) return R.drawable.esp_nutricion;
        if(n.contains("pediatr")) return R.drawable.esp_pediatria;
        if(n.contains("psico")) return R.drawable.esp_psicologia;
        if(n.contains("dermato")) return R.drawable.esp_dermatologia;
        if(n.contains("oftalmo")) return R.drawable.esp_oftalmologia;
        if(n.contains("traumato")) return R.drawable.esp_traumatologia;
        if(n.contains("odonto")) return R.drawable.esp_odontologia;
        if(n.contains("gineco")) return R.drawable.esp_ginecologia;
        if(n.contains("general")) return R.drawable.esp_medicina_general;
        return R.drawable.ic_medico;
    }

    @Override public int getItemCount(){ return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tv;
        ImageView icono;
        androidx.cardview.widget.CardView card;
        VH(View v){
            super(v);
            tv = v.findViewById(R.id.txtEsp);
            icono = v.findViewById(R.id.imgEsp);
            card = v.findViewById(R.id.cardEsp);
        }
    }
}
