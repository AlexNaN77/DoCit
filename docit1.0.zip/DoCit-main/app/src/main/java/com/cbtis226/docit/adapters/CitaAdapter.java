package com.cbtis226.docit.adapters;

import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.cbtis226.docit.R;
import com.cbtis226.docit.model.Cita;
import java.util.List;

public class CitaAdapter extends RecyclerView.Adapter<CitaAdapter.VH> {

    public interface OnTap { void tap(Cita c); }

    List<Cita> data;
    OnTap cb;

    public CitaAdapter(List<Cita> d, OnTap c){ data=d; cb=c; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int v) {
        View x = LayoutInflater.from(p.getContext()).inflate(R.layout.item_cita, p, false);
        return new VH(x);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Cita c = data.get(pos);

        // datos del doctor, todo defensivo
        String nomDoc = "Doctor";
        String esp = "";
        if(c.doctor != null){
            nomDoc = c.doctor.nombreDr();
            if(c.doctor.especialidad != null && c.doctor.especialidad.nombre != null){
                esp = c.doctor.especialidad.nombre;
            }
        }
        if(h.tDoctor != null) h.tDoctor.setText(nomDoc);
        if(h.tEsp != null) h.tEsp.setText(esp);

        String fec = c.fecha == null ? "" : c.fecha;
        if(c.horaInicio != null) fec += "  " + c.horaInicio;
        if(h.tFecha != null) h.tFecha.setText(fec);

        String estado = c.estado == null ? "pendiente" : c.estado;
        if(h.tEstado != null){
            h.tEstado.setText(estado);
            int color;
            switch(estado.toLowerCase()){
                case "confirmada": color = R.color.estadoConfirmada; break;
                case "cancelada": color = R.color.estadoCancelada; break;
                case "completada": color = R.color.estadoCompletada; break;
                default: color = R.color.estadoPendiente;
            }
            try {
                h.tEstado.setBackgroundTintList(
                        h.itemView.getResources().getColorStateList(color)
                );
            } catch(Exception e){}
        }

        h.itemView.setOnClickListener(v -> {
            if(cb != null) cb.tap(c);
        });
    }

    @Override public int getItemCount(){ return data == null ? 0 : data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tDoctor, tEsp, tFecha, tEstado;
        VH(View v){
            super(v);
            tDoctor = v.findViewById(R.id.txtDoctor);
            tEsp = v.findViewById(R.id.txtEsp);
            tFecha = v.findViewById(R.id.txtFecha);
            tEstado = v.findViewById(R.id.txtEstado);
        }
    }
}
