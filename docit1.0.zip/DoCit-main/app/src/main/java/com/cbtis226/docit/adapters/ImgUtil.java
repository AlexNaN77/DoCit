package com.cbtis226.docit.adapters;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.widget.ImageView;
import com.squareup.picasso.Picasso;

public class ImgUtil {

    // carga una imagen que puede ser base64 (data:image...) o una URL normal
    public static void cargar(ImageView img, String fuente, int placeholder){
        if(fuente == null || fuente.isEmpty()){
            img.setImageResource(placeholder);
            return;
        }
        if(fuente.startsWith("data:image") || esBase64Largo(fuente)){
            try {
                String limpio = fuente;
                int coma = fuente.indexOf(',');
                if(coma >= 0) limpio = fuente.substring(coma + 1);
                byte[] bytes = Base64.decode(limpio, Base64.DEFAULT);
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if(bmp != null){
                    img.setImageBitmap(bmp);
                } else {
                    img.setImageResource(placeholder);
                }
            } catch(Exception e){
                img.setImageResource(placeholder);
            }
        } else {
            Picasso.get().load(fuente).placeholder(placeholder).into(img);
        }
    }

    private static boolean esBase64Largo(String s){
        return s.length() > 200 && !s.startsWith("http");
    }
}
