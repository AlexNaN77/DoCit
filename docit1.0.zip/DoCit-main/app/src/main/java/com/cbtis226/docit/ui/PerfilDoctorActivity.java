package com.cbtis226.docit.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.cbtis226.docit.R;
import com.cbtis226.docit.adapters.*;
import com.cbtis226.docit.model.*;
import com.cbtis226.docit.net.ApiCliente;
import com.smarteist.autoimageslider.SliderView;
import java.net.URLEncoder;
import java.util.*;
import retrofit2.*;

public class PerfilDoctorActivity extends AppCompatActivity {

    String idDoc;
    Doctor doc;
    TextView lblNombre, lblEsp, lblCalif, lblDesc, lblHorario, lblDireccion;
    View boxHorario, lblUbicacionTitulo, cardMapa, btnAbrirMapa;
    WebView mapaWeb;
    SliderView slider;
    RecyclerView rvServ, rvRes;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_perfil_doctor);

        idDoc = getIntent().getStringExtra("idDoctor");
        lblNombre = findViewById(R.id.lblNombreDoc);
        lblEsp = findViewById(R.id.lblEsp);
        lblCalif = findViewById(R.id.lblCalif);
        lblDesc = findViewById(R.id.lblDesc);
        lblHorario = findViewById(R.id.lblHorario);
        lblDireccion = findViewById(R.id.lblDireccion);
        boxHorario = findViewById(R.id.boxHorario);
        lblUbicacionTitulo = findViewById(R.id.lblUbicacionTitulo);
        cardMapa = findViewById(R.id.cardMapa);
        btnAbrirMapa = findViewById(R.id.btnAbrirMapa);
        mapaWeb = findViewById(R.id.mapaWeb);
        slider = findViewById(R.id.imageSlider);
        rvServ = findViewById(R.id.rvServicios);
        rvRes = findViewById(R.id.rvResenas);

        rvServ.setLayoutManager(new LinearLayoutManager(this));
        rvRes.setLayoutManager(new LinearLayoutManager(this));

        findViewById(R.id.btnAgendar).setOnClickListener(v -> {
            if(doc == null) return;
            Intent i = new Intent(this, CrearCitaActivity.class);
            i.putExtra("idDoctor", doc.idDoctor);
            startActivity(i);
        });
        findViewById(R.id.btnWhats).setOnClickListener(v -> {
            if(doc == null) return;
            String w = doc.whatsapp != null ? doc.whatsapp : doc.telefono;
            if(w == null) return;
            try {
                Intent in = new Intent(Intent.ACTION_VIEW);
                in.setData(Uri.parse("https://wa.me/" + w.replaceAll("\\D","")));
                startActivity(in);
            } catch(Exception e){ }
        });
        findViewById(R.id.btnLlamar).setOnClickListener(v -> {
            if(doc == null || doc.telefono == null) return;
            Intent c = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + doc.telefono));
            startActivity(c);
        });

        cargar();
    }

    void cargar(){
        ApiCliente.api().doctor(idDoc).enqueue(new Callback<Doctor>() {
            @Override public void onResponse(Call<Doctor> call, Response<Doctor> r) {
                if(r.isSuccessful() && r.body() != null){
                    doc = r.body();
                    pintar();
                } else {
                    cargarDummy();
                }
            }
            @Override public void onFailure(Call<Doctor> call, Throwable t) {
                cargarDummy();
            }
        });
    }

    void cargarDummy(){
        doc = new Doctor();
        doc.idDoctor = idDoc != null ? idDoc : "doc_demo";
        doc.nombre = "Dr. Roberto Mendoza Luna";
        doc.descripcion = "Médico cirujano con 12 años de experiencia. Atiende citas particulares y de emergencia.";
        doc.promedioCalificacion = 4.7;
        doc.direccion = "Av. Reforma 123, Col. Centro, Ciudad Guzmán, Jal.";
        doc.horarioTexto = "Lun-Vie 9:00-14:00 y 16:00-20:00";
        Especialidad e = new Especialidad();
        e.nombre = "Medicina general";
        doc.especialidad = e;
        doc.imagenes = new ArrayList<>();
        String[] urls = {
                "https://picsum.photos/seed/d1/600/400",
                "https://picsum.photos/seed/d2/600/400"
        };
        for(String u : urls){
            Imagen im = new Imagen();
            im.urlImagen = u;
            doc.imagenes.add(im);
        }
        doc.servicios = new ArrayList<>();
        String[] ns = {"Consulta general","Receta médica","Chequeo anual"};
        double[] ps = {350, 200, 800};
        for(int i=0;i<ns.length;i++){
            Servicio s = new Servicio();
            s.idServicio = "s"+i;
            s.nombre = ns[i];
            s.precio = ps[i];
            s.duracion = 30;
            s.descripcion = "Servicio profesional con atención personalizada.";
            doc.servicios.add(s);
        }
        doc.resenas = new ArrayList<>();
        pintar();
    }

    @SuppressLint("SetJavaScriptEnabled")
    void pintar(){
        lblNombre.setText(doc.nombreDr());
        lblEsp.setText(doc.especialidad != null ? doc.especialidad.nombre : "");
        lblCalif.setText(String.format("%.1f ★ (%d reseñas)",
                doc.promedioCalificacion == null ? 0 : doc.promedioCalificacion,
                doc.resenas == null ? 0 : doc.resenas.size()));
        lblDesc.setText(doc.descripcion != null ? doc.descripcion : "");

        // horario
        if(doc.horarioTexto != null && !doc.horarioTexto.isEmpty()){
            boxHorario.setVisibility(View.VISIBLE);
            lblHorario.setText(doc.horarioTexto);
        }

        // direccion + mapa
        boolean hayDir = doc.direccion != null && !doc.direccion.isEmpty();
        boolean hayMaps = doc.mapsUrl != null && !doc.mapsUrl.isEmpty();
        if(hayDir || hayMaps){
            lblUbicacionTitulo.setVisibility(View.VISIBLE);
        }
        if(hayDir){
            lblDireccion.setVisibility(View.VISIBLE);
            lblDireccion.setText("📍 " + doc.direccion);
        }

        // mapa embebido: usamos la direccion para mostrarlo
        String consulta = hayDir ? doc.direccion : null;
        if(consulta != null){
            try {
                cardMapa.setVisibility(View.VISIBLE);
                mapaWeb.getSettings().setJavaScriptEnabled(true);
                String q = URLEncoder.encode(consulta, "UTF-8");
                String html = "<html><body style='margin:0;padding:0'>" +
                        "<iframe width='100%' height='100%' frameborder='0' style='border:0' " +
                        "src='https://maps.google.com/maps?q=" + q + "&output=embed'></iframe>" +
                        "</body></html>";
                mapaWeb.loadData(html, "text/html", "UTF-8");
            } catch(Exception e){
                cardMapa.setVisibility(View.GONE);
            }
        }

        // boton abrir maps
        if(hayMaps || hayDir){
            btnAbrirMapa.setVisibility(View.VISIBLE);
            btnAbrirMapa.setOnClickListener(v -> abrirMaps());
        }

        // slider de imagenes
        List<String> imgs = new ArrayList<>();
        if(doc.imagenes != null){
            for(Imagen im : doc.imagenes) imgs.add(im.urlImagen);
        }
        slider.setSliderAdapter(new ImagenSliderAdapter(imgs));

        if(doc.servicios != null){
            rvServ.setAdapter(new ServicioAdapter(doc.servicios));
        }
        if(doc.resenas != null){
            rvRes.setAdapter(new ResenaAdapter(doc.resenas));
        }
    }

    void abrirMaps(){
        try {
            String url;
            if(doc.mapsUrl != null && !doc.mapsUrl.isEmpty()){
                url = doc.mapsUrl;
            } else {
                url = "https://www.google.com/maps/search/?api=1&query=" +
                        URLEncoder.encode(doc.direccion, "UTF-8");
            }
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(i);
        } catch(Exception e){ }
    }
}
