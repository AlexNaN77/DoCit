package com.cbtis226.docit.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.cbtis226.docit.DoCitApp;
import com.cbtis226.docit.R;
import com.cbtis226.docit.adapters.HistorialPerfilAdapter;
import com.cbtis226.docit.model.Cita;
import com.cbtis226.docit.model.Usuario;
import com.cbtis226.docit.net.ApiCliente;
import com.squareup.picasso.Picasso;
import java.util.*;
import retrofit2.*;

public class PerfilUsuarioActivity extends AppCompatActivity {

    List<Cita> citasHist = new ArrayList<>();
    HistorialPerfilAdapter ad;
    RecyclerView rv;
    TextView sinHist;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_perfil_usuario);

        Usuario u = DoCitApp.x().usuarioLogeado;
        TextView lblN = findViewById(R.id.lblNombre);
        TextView lblC = findViewById(R.id.lblCorreo);
        TextView dNom = findViewById(R.id.datoNombre);
        TextView dCurp = findViewById(R.id.datoCurp);
        TextView dTel = findViewById(R.id.datoTel);
        ImageView img = findViewById(R.id.imgPerfil);
        rv = findViewById(R.id.rvHistorial);
        sinHist = findViewById(R.id.lblSinHist);

        if(u != null){
            lblN.setText(u.nombreCompleto());
            lblC.setText(u.correo);
            dNom.setText(u.nombreCompleto());
            dCurp.setText(u.curp == null ? "—" : u.curp);
            dTel.setText(u.telefono == null ? "—" : u.telefono);
            if(u.fotoPerfil != null && !u.fotoPerfil.isEmpty()){
                Picasso.get().load(u.fotoPerfil).placeholder(R.drawable.ic_persona_b).into(img);
            }
        }

        rv.setLayoutManager(new LinearLayoutManager(this));
        ad = new HistorialPerfilAdapter(citasHist);
        rv.setAdapter(ad);

        findViewById(R.id.btnEditar).setOnClickListener(v ->
                startActivity(new Intent(this, EditarPerfilActivity.class)));
        findViewById(R.id.btnCerrar).setOnClickListener(v -> cerrarSesion());
        findViewById(R.id.btnMenu).setOnClickListener(v -> finish());

        // nav inferior
        findViewById(R.id.navHome).setOnClickListener(v -> {
            startActivity(new Intent(this, PrincipalActivity.class));
            finish();
        });
        findViewById(R.id.navBuscar).setOnClickListener(v ->
                startActivity(new Intent(this, BuscarDoctorActivity.class)));
        findViewById(R.id.navCitas).setOnClickListener(v ->
                startActivity(new Intent(this, HistorialActivity.class)));
        // perfil ya estamos aqui, no hace nada o reload
        findViewById(R.id.navPerfil).setOnClickListener(v -> {});

        cargarHistorial();
    }

    void cargarHistorial(){
        Usuario u = DoCitApp.x().usuarioLogeado;
        if(u == null) return;
        ApiCliente.api().misCitas(u.idUsuario).enqueue(new Callback<List<Cita>>() {
            @Override public void onResponse(Call<List<Cita>> call, Response<List<Cita>> r) {
                citasHist.clear();
                if(r.isSuccessful() && r.body() != null){
                    citasHist.addAll(r.body());
                }
                refrescar();
            }
            @Override public void onFailure(Call<List<Cita>> call, Throwable t) {
                refrescar();
            }
        });
    }

    void refrescar(){
        ad.notifyDataSetChanged();
        sinHist.setVisibility(citasHist.isEmpty() ? View.VISIBLE : View.GONE);
        rv.setVisibility(citasHist.isEmpty() ? View.GONE : View.VISIBLE);
    }

    void cerrarSesion(){
        new AlertDialog.Builder(this)
                .setTitle("Cerrar sesión")
                .setMessage("Seguro que quieres salir?")
                .setPositiveButton("Sí", (d,w) -> {
                    DoCitApp.x().cerrarSesion();
                    Intent i = new Intent(this, LoginActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .setNegativeButton("No", null)
                .show();
    }
}