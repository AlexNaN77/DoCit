#!/bin/bash
PKG="app/src/main/java/com/cbtis/studeTIS"
LAY="app/src/main/res/layout"
DRW="app/src/main/res/drawable"
VAL="app/src/main/res/values"

mkdir -p $PKG $LAY $DRW $VAL

# java
for f in Config ApiCliente ApiFake Sesion SplashActivity LoginActivity \
         RegistroActivity BienvenidaActivity SemestreActivity HomeActivity \
         PerfilActivity DiarioActivity PendientesActivity RecordatoriosActivity \
         MateriasActivity MateriaDetalleActivity SemanaActivity NotasActivity \
         DadosActivity; do
  touch $PKG/$f.java
done

# layouts
for f in activity_splash activity_login activity_registro activity_bienvenida \
         activity_semestre activity_home activity_perfil activity_diario \
         activity_pendientes activity_recordatorios activity_materias \
         activity_materia_detalle activity_semana activity_notas activity_dados \
         item_pendiente item_recordatorio item_diario item_materia \
         item_tarea item_dia item_evento item_nota; do
  touch $LAY/$f.xml
done

# drawables
for f in btn_amarillo btn_rosa btn_verde btn_azul btn_rojo card_borde input_borde; do
  touch $DRW/$f.xml
done

echo "listo wey, ahora a pegar"
